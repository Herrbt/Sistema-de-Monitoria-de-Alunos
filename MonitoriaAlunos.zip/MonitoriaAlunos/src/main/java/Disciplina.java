public class Disciplina {
    private String codigo; // Ex: "POO01"
    private String nome;   // Ex: "Programação Orientada a Objetos"

    public Disciplina(String codigo, String nome) {
        this.codigo = codigo;
        this.nome = nome;
    }

    // Getters e Setters
    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    // Método de exibição
    public void exibirInformacoes() {
        System.out.println("Disciplina: " + nome + " [" + codigo + "]");
    }
}