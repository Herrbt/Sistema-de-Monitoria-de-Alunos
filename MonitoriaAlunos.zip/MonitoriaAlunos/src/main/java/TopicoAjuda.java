public class TopicoAjuda {
    private String descricao;      // Ex: "Dúvida sobre Herança e Polimorfismo"
    private Disciplina disciplina; // Conecta a dúvida a uma disciplina específica

    public TopicoAjuda(String descricao, Disciplina disciplina) {
        this.descricao = descricao;
        this.disciplina = disciplina;
    }

    // Getters e Setters
    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public Disciplina getDisciplina() {
        return disciplina;
    }

    public void setDisciplina(Disciplina disciplina) {
        this.disciplina = disciplina;
    }

    // Exibe os detalhes do tópico de ajuda
    public void exibirInformacoes() {
        System.out.println("Assunto: " + descricao);
        if (disciplina != null) {
            System.out.println("Disciplina: " + disciplina.getNome());
        }
    }
}