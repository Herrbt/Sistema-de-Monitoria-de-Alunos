public class SessaoMonitoria {
    private Agendamento agendamento;
    private Monitor monitor;
    private RelatorioSessao relatorio;
    private boolean concluida;

    // Construtor com Validação de Agendamento (Regra 3)
    public SessaoMonitoria(Agendamento agendamento, Monitor monitor) {
        // Regra 3: A sessão exige que o agendamento esteja no status "Confirmado"
        if (agendamento == null || !"Confirmado".equalsIgnoreCase(agendamento.getStatus())) {
            throw new IllegalArgumentException("Erro: A sessão só pode ser iniciada se o agendamento estiver com status 'Confirmado'.");
        }

        this.agendamento = agendamento;
        this.monitor = monitor;
        this.concluida = false;
        this.relatorio = null;
    }

    // Método para finalizar a sessão exigindo o relatório (Regra 5)
    public boolean finalizarSessao(RelatorioSessao relatorio) {
        if (relatorio == null) {
            System.out.println("Erro: Não é possível encerrar a sessão sem associar um Relatório de Sessão.");
            return false;
        }

        this.relatorio = relatorio;
        this.concluida = true;
        this.agendamento.setStatus("Concluido");
        System.out.println("Sessão de monitoria finalizada com sucesso!");
        return true;
    }

    // Getters
    public Agendamento getAgendamento() {
        return agendamento;
    }

    public Monitor getMonitor() {
        return monitor;
    }

    public RelatorioSessao getRelatorio() {
        return relatorio;
    }

    public boolean isConcluida() {
        return concluida;
    }

    // Exibição do resumo da sessão
    public void exibirInformacoes() {
        System.out.println("=== Detalhes da Sessão de Monitoria ===");
        System.out.println("Monitor: " + monitor.getNome());
        System.out.println("Data/Hora: " + agendamento.getDataHora());
        System.out.println("Status da Sessão: " + (concluida ? "Concluída" : "Em Andamento"));
        if (relatorio != null) {
            System.out.println("Resumo do Atendimento: " + relatorio.getDescricaoAtendimento());
            System.out.println("Dúvida Resolvida: " + (relatorio.isDuvidaResolvida() ? "Sim" : "Não"));
        }
    }
}