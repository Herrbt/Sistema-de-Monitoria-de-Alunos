import java.util.ArrayList;
import java.util.Scanner;

public class App {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Instanciação dos dados base para teste
        Disciplina poo = new Disciplina("POO01", "Programação Orientada a Objetos");
        Monitor monitor = new Monitor("M100", "Lucas Silva", poo);

        ArrayList<Agendamento> agendamentos = new ArrayList<>();
        SessaoMonitoria sessaoAtiva = null;

        int opcao = -1;

        while (opcao != 0) {
            System.out.println("\n  SISTEMA DE MONITORIA - MENU PRINCIPAL \n");
            System.out.println("1. Solicitar novo Agendamento (Aluno)");
            System.out.println("2. Confirmar Agendamento (Monitor - Prevenção de Conflito)");
            System.out.println("3. Iniciar Sessão de Monitoria (Validação de Status)");
            System.out.println("4. Finalizar Sessão com Relatório (Obrigatório)");
            System.out.println("5. Exibir Agendamentos e Dados do Monitor");
            System.out.println("0. Sair");
            System.out.print("Escolha uma opção: ");

            try {
                opcao = Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Opção inválida! Digite um número inteiro.");
                continue;
            }

            switch (opcao) {
                case 1 -> {
                    System.out.println("\n--- [1] Novo Agendamento ---");
                    System.out.print("Data e Hora (ex: 10/10/2026 14:00): ");
                    String dataHora = scanner.nextLine();
                    System.out.print("Descrição da Dúvida: ");
                    String descricaoDuvida = scanner.nextLine();

                    TopicoAjuda topico = new TopicoAjuda(descricaoDuvida, poo);
                    Agendamento novoAgendamento = new Agendamento(dataHora, topico);
                    agendamentos.add(novoAgendamento);

                    System.out.println("-> Agendamento criado! Status atual: " + novoAgendamento.getStatus());
                }

                case 2 -> {
                    System.out.println("\n--- [2] Confirmar Agendamento ---");
                    if (agendamentos.isEmpty()) {
                        System.out.println("Nenhum agendamento cadastrado para confirmar.");
                        break;
                    }

                    for (int i = 0; i < agendamentos.size(); i++) {
                        Agendamento a = agendamentos.get(i);
                        System.out.println("[" + i + "] " + a.getDataHora() + " | Dúvida: " + a.getTopicoAjuda().getDescricao() + " | Status: " + a.getStatus());
                    }

                    System.out.print("Selecione o índice do agendamento a confirmar: ");
                    int idxConfirm = Integer.parseInt(scanner.nextLine());

                    if (idxConfirm >= 0 && idxConfirm < agendamentos.size()) {
                        monitor.confirmarAgendamento(agendamentos.get(idxConfirm));
                    } else {
                        System.out.println("Índice inválido.");
                    }
                }

                case 3 -> {
                    System.out.println("\n--- [3] Iniciar Sessão de Monitoria ---");
                    if (agendamentos.isEmpty()) {
                        System.out.println("Nenhum agendamento disponível.");
                        break;
                    }

                    System.out.print("Digite o índice do agendamento para iniciar a sessão: ");
                    int idxSessao = Integer.parseInt(scanner.nextLine());

                    if (idxSessao >= 0 && idxSessao < agendamentos.size()) {
                        try {
                            sessaoAtiva = new SessaoMonitoria(agendamentos.get(idxSessao), monitor);
                            System.out.println("-> Sessão iniciada com sucesso!");
                        } catch (IllegalArgumentException e) {
                            System.out.println("-> " + e.getMessage());
                        }
                    } else {
                        System.out.println("Índice inválido.");
                    }
                }

                case 4 -> {
                    System.out.println("\n--- [4] Finalizar Sessão de Monitoria ---");
                    if (sessaoAtiva == null || sessaoAtiva.isConcluida()) {
                        System.out.println("Nenhuma sessão em andamento para finalizar.");
                        break;
                    }

                    System.out.print("Descrição do atendimento realizado: ");
                    String desc = scanner.nextLine();
                    System.out.print("A dúvida foi totalmente resolvida? (true/false): ");
                    boolean resolvida = Boolean.parseBoolean(scanner.nextLine());
                    System.out.print("Recomendações de estudo passadas ao aluno: ");
                    String recomendacoes = scanner.nextLine();

                    RelatorioSessao relatorio = new RelatorioSessao(desc, resolvida, recomendacoes);
                    boolean finalizada = sessaoAtiva.finalizarSessao(relatorio);

                    if (finalizada) {
                        System.out.println();
                        sessaoAtiva.exibirInformacoes();
                    }
                }

                case 5 -> {
                    System.out.println("\n--- [5] Dados Cadastrados ---");
                    monitor.exibirInformacoes();
                    System.out.println("\nTotal de Agendamentos no Sistema: " + agendamentos.size());
                    for (Agendamento a : agendamentos) {
                        a.exibirInformacoes();
                        System.out.println("----------------------------------------");
                    }
                }

                case 0 -> System.out.println("Saindo do sistema...");

                default -> System.out.println("Opção inválida!");
            }
        }

        scanner.close();
    }
}