import java.util.ArrayList;

public class Monitor {
    private String matricula;
    private String nome;
    private Disciplina disciplina;
    private ArrayList<Agendamento> agendamentos;

    public Monitor(String matricula, String nome, Disciplina disciplina) {
        this.matricula = matricula;
        this.nome = nome;
        this.disciplina = disciplina;
        this.agendamentos = new ArrayList<>();
    }

    // Regra 1: Prevenção de Conflito de Horários
    public boolean confirmarAgendamento(Agendamento agendamento) {
        if (agendamento == null) {
            System.out.println("Erro: Agendamento inválido.");
            return false;
        }

        // Percorre os agendamentos existentes para checar choque de horário
        for (Agendamento a : this.agendamentos) {
            if (a.getDataHora().equalsIgnoreCase(agendamento.getDataHora()) 
                    && "Confirmado".equalsIgnoreCase(a.getStatus())) {
                System.out.println("Erro: O monitor " + nome + " já possui atendimento confirmado no horário " + agendamento.getDataHora());
                return false;
            }
        }

        // Se não houver choque, confirma o pedido
        agendamento.setStatus("Confirmado");

        if (!this.agendamentos.contains(agendamento)) {
            this.agendamentos.add(agendamento);
        }

        System.out.println("Agendamento em " + agendamento.getDataHora() + " confirmado para o monitor " + nome + "!");
        return true;
    }

    // Getters e Setters
    public String getMatricula() {
        return matricula;
    }

    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Disciplina getDisciplina() {
        return disciplina;
    }

    public void setDisciplina(Disciplina disciplina) {
        this.disciplina = disciplina;
    }

    public ArrayList<Agendamento> getAgendamentos() {
        return agendamentos;
    }

    // Método utilitário para exibições
    public void exibirInformacoes() {
        System.out.println("=== Monitor: " + nome + " (" + matricula + ") ===");
        if (disciplina != null) {
            System.out.println("Disciplina: " + disciplina.getNome());
        }
        System.out.println("Agendamentos Vinculados: " + agendamentos.size());
    }
}