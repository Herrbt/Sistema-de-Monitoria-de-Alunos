public class RelatorioSessao {
    private String descricaoAtendimento;
    private boolean duvidaResolvida;
    private String recomendacoesEstudo;

    public RelatorioSessao(String descricaoAtendimento, boolean duvidaResolvida, String recomendacoesEstudo) {
        this.descricaoAtendimento = descricaoAtendimento;
        this.duvidaResolvida = duvidaResolvida;
        this.recomendacoesEstudo = recomendacoesEstudo;
    }

    // Getters e Setters
    public String getDescricaoAtendimento() {
        return descricaoAtendimento;
    }

    public void setDescricaoAtendimento(String descricaoAtendimento) {
        this.descricaoAtendimento = descricaoAtendimento;
    }

    public boolean isDuvidaResolvida() {
        return duvidaResolvida;
    }

    public void setDuvidaResolvida(boolean duvidaResolvida) {
        this.duvidaResolvida = duvidaResolvida;
    }

    public String getRecomendacoesEstudo() {
        return recomendacoesEstudo;
    }

    public void setRecomendacoesEstudo(String recomendacoesEstudo) {
        this.recomendacoesEstudo = recomendacoesEstudo;
    }

    // Exibição detalhada do relatório
    public void exibirRelatorio() {
        System.out.println("--- Relatório Final de Atendimento ---");
        System.out.println("Descrição do que foi trabalhado: " + descricaoAtendimento);
        System.out.println("Dúvida foi solucionada? " + (duvidaResolvida ? "Sim" : "Não"));
        System.out.println("Recomendações de estudo: " + recomendacoesEstudo);
    }
}