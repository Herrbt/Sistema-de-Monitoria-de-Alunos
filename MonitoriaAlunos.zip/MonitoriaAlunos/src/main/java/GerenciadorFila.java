import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class GerenciadorFila {
    private List<Agendamento> filaAtendimento;

    public GerenciadorFila() {
        this.filaAtendimento = new ArrayList<>();
    }

    // Adiciona um agendamento à fila e reordena por prioridade
    public void adicionarFila(Agendamento agendamento) {
        if (agendamento != null) {
            filaAtendimento.add(agendamento);
            ordenarFilaPorPrioridade();
            System.out.println("-> Agendamento adicionado à fila. Posições atualizadas por prioridade.");
        }
    }

    // Regra de Negócio: Prioriza alunos com média entre 0.0 e 6.9
    public void ordenarFilaPorPrioridade() {
        filaAtendimento.sort(new Comparator<Agendamento>() {
            @Override
            public int compare(Agendamento a1, Agendamento a2) {
                boolean p1 = a1.getAluno() != null && a1.getAluno().temPrioridade();
                boolean p2 = a2.getAluno() != null && a2.getAluno().temPrioridade();

                if (p1 && !p2) {
                    return -1; // a1 vem primeiro
                }
                if (!p1 && p2) {
                    return 1;  // a2 vem primeiro
                }
                return 0;      // mantêm a ordem de chegada
            }
        });
    }

    public Agendamento proximoAtendimento() {
        if (filaAtendimento.isEmpty()) {
            return null;
        }
        return filaAtendimento.remove(0);
    }

    public List<Agendamento> getFilaAtendimento() {
        return filaAtendimento;
    }
}