import com.fasterxml.jackson.annotation.JsonIgnore;

public class Agendamento {

    private String dataHora;      // Ex: "10/10/2026 14:00"
    private String status;        // "Pendente", "Confirmado", "Cancelado"
    private TopicoAjuda topicoAjuda;

    @JsonIgnore // Evita loop infinito no JSON (Aluno -> Agendamento -> Aluno)
    private Aluno aluno;

    public Agendamento() {
        // Construtor vazio é OBRIGATÓRIO para o Jackson conseguir ler (deserializar) o JSON de volta para objeto
    }

    // Construtor alternativo com 2 parâmetros (compatível com a chamada antiga no App.java)
    public Agendamento(String dataHora, TopicoAjuda topicoAjuda) {
        this.dataHora = dataHora;
        this.topicoAjuda = topicoAjuda;
        this.status = "Pendente";
    }

    // Construtor principal com 3 parâmetros
    public Agendamento(String dataHora, TopicoAjuda topicoAjuda, Aluno aluno) {
        this.dataHora = dataHora;
        this.topicoAjuda = topicoAjuda;
        this.aluno = aluno;
        this.status = "Pendente";
    }

    // Getters e Setters
    public String getDataHora() {
        return dataHora;
    }

    public void setDataHora(String dataHora) {
        this.dataHora = dataHora;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public TopicoAjuda getTopicoAjuda() {
        return topicoAjuda;
    }

    public void setTopicoAjuda(TopicoAjuda topicoAjuda) {
        this.topicoAjuda = topicoAjuda;
    }

    public Aluno getAluno() {
        return aluno;
    }

    public void setAluno(Aluno aluno) { 
        this.aluno = aluno;
    }

    // Método utilitário para exibir os detalhes do agendamento
    public void exibirInformacoes() {
        System.out.println("Data/Hora: " + dataHora + " | Status: " + status);
        if (topicoAjuda != null) {
            System.out.println("Tópico de Dúvida: " + topicoAjuda.getDescricao());
        }
        if (aluno != null) {
            System.out.println("Aluno: " + aluno.getNome());
        }
    }
}