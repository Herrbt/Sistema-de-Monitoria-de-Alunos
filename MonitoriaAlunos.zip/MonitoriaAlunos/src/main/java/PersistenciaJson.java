import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class PersistenciaJson {

    private static final String CAMINHO_ARQUIVO = "sistema_monitoria.json";
    private static final ObjectMapper objectMapper = new ObjectMapper();

    static {
        // Habilita a formatação bonita (indentada) do JSON no arquivo
        objectMapper.enable(SerializationFeature.INDENT_OUTPUT);
    }

    // Salvar lista de alunos no arquivo JSON
    public static void salvarAlunos(List<Aluno> alunos) {
        try {
            objectMapper.writeValue(new File(CAMINHO_ARQUIVO), alunos);
            System.out.println("-> Dados salvos com sucesso no arquivo: " + CAMINHO_ARQUIVO);
        } catch (IOException e) {
            System.out.println("-> Erro ao salvar arquivo JSON: " + e.getMessage());
        }
    }

    // Carregar lista de alunos do arquivo JSON
    public static List<Aluno> carregarAlunos() {
        File arquivo = new File(CAMINHO_ARQUIVO);
        if (!arquivo.exists()) {
            System.out.println("-> Arquivo JSON não encontrado. Iniciando nova lista vazia.");
            return new ArrayList<>();
        }

        try {
            return objectMapper.readValue(arquivo, 
                objectMapper.getTypeFactory().constructCollectionType(List.class, Aluno.class));
        } catch (IOException e) {
            System.out.println("-> Erro ao ler o arquivo JSON: " + e.getMessage());
            return new ArrayList<>();
        }
    }
}