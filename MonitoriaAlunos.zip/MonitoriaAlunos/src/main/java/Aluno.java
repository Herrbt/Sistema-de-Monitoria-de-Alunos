import java.util.ArrayList;

public class Aluno {
    private String nome;
    private String matricula;
    private ArrayList<Double> notas;
    private ArrayList<Agendamento> agendamentos;

    public Aluno(String matricula, String nome) {
        this.matricula = matricula;
        this.nome = nome;
        this.notas = new ArrayList<>();
        this.agendamentos = new ArrayList<>();
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getMatricula() {
        return matricula;
    }

    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }

    public ArrayList<Double> getNotas() {
        return notas;
    }

    public void setNotas(ArrayList<Double> notas) {
        this.notas = notas;
    }

    public ArrayList<Agendamento> getAgendamentos() {
        return agendamentos;
    }

    public void setAgendamentos(ArrayList<Agendamento> agendamentos) {
        this.agendamentos = agendamentos;
    }

    public void adicionarNota(double nota) {
        this.notas.add(nota);
    }

    public void adicionarAgendamento(Agendamento agendamento) {
        this.agendamentos.add(agendamento);
    }

    public double calcularMedia() {
        if (notas.isEmpty()) {
            return 0.0;
        }
        double soma = 0;
        for (double nota : notas) {
            soma += nota;
        }
        return soma / notas.size();
    }

    // Regra de Negócio 2: Prioridade se a média estiver entre 0.0 e 6.9
    public boolean temPrioridade() {
        double media = calcularMedia();
        return media >= 0.0 && media <= 6.9;
    }

    // Regra de Negócio 4: Limite máximo de 2 agendamentos ativos
    public boolean podeNovoAgendamento() {
        int ativos = 0;
        for (Agendamento a : this.agendamentos) {
            if ("Pendente".equals(a.getStatus()) || "Confirmado".equals(a.getStatus())) {
                ativos++;
            }
        }
        return ativos < 2;
    }

    // Método utilitário opcional para tentar agendar de forma segura
    public boolean tentarAgendar(Agendamento agendamento) {
        if (podeNovoAgendamento()) {
            adicionarAgendamento(agendamento);
            System.out.println("-> Agendamento criado com sucesso para " + this.nome);
            return true;
        } else {
            System.out.println("-> Erro: O aluno " + this.nome + " atingiu o limite de 2 agendamentos ativos.");
            return false;
        }
    }
}