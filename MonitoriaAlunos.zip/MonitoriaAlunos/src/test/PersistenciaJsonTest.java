import org.junit.jupiter.api.Test;
import java.util.ArrayList;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

public class PersistenciaJsonTest {

    @Test
    public void testSalvarECarregarJson() {
        // 1. Criar dados de exemplo
        List<Aluno> alunosOriginais = new ArrayList<>();
        Aluno aluno = new Aluno("9999", "Roberto Carlos");
        aluno.adicionarNota(6.5);
        alunosOriginais.add(aluno);

        // 2. Salvar em JSON
        PersistenciaJson.salvarAlunos(alunosOriginais);

        // 3. Carregar de volta do JSON
        List<Aluno> alunosCarregados = PersistenciaJson.carregarAlunos();

        // 4. Validar se os dados batem certo
        assertFalse(alunosCarregados.isEmpty(), "A lista carregada não deve estar vazia.");
        assertEquals("9999", alunosCarregados.get(0).getMatricula());
        assertEquals("Roberto Carlos", alunosCarregados.get(0).getNome());
        assertEquals(6.5, alunosCarregados.get(0).calcularMedia());
    }
}