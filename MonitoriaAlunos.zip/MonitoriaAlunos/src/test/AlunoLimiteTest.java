import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class AlunoLimiteTest {

    @Test
    public void testLimiteAgendamentosAtivos() {
        Aluno aluno = new Aluno("202305", "Mariana Costa");
        Disciplina disciplina = new Disciplina("FIS01", "Física");
        TopicoAjuda topico = new TopicoAjuda("Cinemática", disciplina);

        // 1º Agendamento - Deve ser permitido
        assertTrue(aluno.podeNovoAgendamento(), "Aluno deve poder fazer o 1º agendamento.");
        Agendamento ag1 = new Agendamento("12/10/2026 10:00", topico, aluno);
        aluno.adicionarAgendamento(ag1);

        // 2º Agendamento - Deve ser permitido
        assertTrue(aluno.podeNovoAgendamento(), "Aluno deve poder fazer o 2º agendamento.");
        Agendamento ag2 = new Agendamento("13/10/2026 10:00", topico, aluno);
        aluno.adicionarAgendamento(ag2);

        // 3º Agendamento - DEVE SER BLOQUEADO (atingiu o limite de 2)
        assertFalse(aluno.podeNovoAgendamento(), "Aluno NÃO deve poder fazer um 3º agendamento ativo.");
    }
}