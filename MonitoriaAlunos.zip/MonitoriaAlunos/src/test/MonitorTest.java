import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class MonitorTest {

    @Test
    public void testPrevensaoConflitoHorario() {
        // 1. Cenário: Criar disciplina, monitor e dois agendamentos no mesmo horário
        Disciplina disciplina = new Disciplina("POO01", "Programação Orientada a Objetos");
        Monitor monitor = new Monitor("M100", "Lucas Silva", disciplina);

        TopicoAjuda topico1 = new TopicoAjuda("Dúvida sobre Herança", disciplina);
        TopicoAjuda topico2 = new TopicoAjuda("Dúvida sobre Polimorfismo", disciplina);

        Agendamento ag1 = new Agendamento("15/10/2026 14:00", topico1);
        Agendamento ag2 = new Agendamento("15/10/2026 14:00", topico2);

        // 2. Ação: Confirmar o primeiro agendamento
        boolean primeiroConfirmado = monitor.confirmarAgendamento(ag1);

        // 3. Validação: O primeiro deve ser confirmado com sucesso
        assertTrue(primeiroConfirmado, "O primeiro agendamento deveria ser confirmado.");
        assertEquals("Confirmado", ag1.getStatus(), "O status do agendamento 1 deve ser 'Confirmado'.");

        // 4. Ação e Validação: Tentar confirmar o segundo agendamento no mesmo horário
        boolean segundoConfirmado = monitor.confirmarAgendamento(ag2);

        // O segundo deve ser rejeitado por causa do conflito de horário
        assertFalse(segundoConfirmado, "O segundo agendamento no mesmo horário deve ser recusado.");
    }
}
