import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class GerenciadorFilaTest {

    @Test
    public void testFilaPrioridadeMediaBaixa() {
        // 1. Criar disciplina e tópico de ajuda
        Disciplina disciplina = new Disciplina("MAT01", "Matemática");
        TopicoAjuda topico = new TopicoAjuda("Derivadas", disciplina);

        // 2. Criar Aluno 1: Média alta (8.5) -> NÃO tem prioridade
        Aluno alunoNormal = new Aluno("202301", "Carlos Silva");
        alunoNormal.adicionarNota(8.0);
        alunoNormal.adicionarNota(9.0); // Média = 8.5

        // 3. Criar Aluno 2: Média baixa (5.5) -> TEM prioridade (entre 0.0 e 6.9)
        Aluno alunoPrioridade = new Aluno("202302", "Ana Souza");
        alunoPrioridade.adicionarNota(5.0);
        alunoPrioridade.adicionarNota(6.0); // Média = 5.5

        // 4. Criar agendamentos para ambos
        Agendamento agNormal = new Agendamento("15/10/2026 14:00", topico, alunoNormal);
        Agendamento agPrioridade = new Agendamento("15/10/2026 15:00", topico, alunoPrioridade);

        GerenciadorFila gerenciador = new GerenciadorFila();

        // 5. Adicionar primeiro o aluno normal, e depois o aluno com prioridade
        gerenciador.adicionarFila(agNormal);
        gerenciador.adicionarFila(agPrioridade);

        // 6. O próximo da fila DEVE ser o aluno com prioridade (Ana Souza), mesmo tendo entrado depois
        Agendamento proximoAtendimento = gerenciador.proximoAtendimento();

        assertNotNull(proximoAtendimento, "A fila não deve estar vazia.");
        assertEquals("202302", proximoAtendimento.getAluno().getMatricula(), 
            "O aluno com média baixa (entre 0.0 e 6.9) deve furar a fila e ser atendido primeiro!");
    }
}
